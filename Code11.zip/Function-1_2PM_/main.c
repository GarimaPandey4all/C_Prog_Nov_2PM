#include <stdio.h>
#include <stdlib.h>

/*
    Function is a particular task that provides reuse ability.

    Function has four types:

    1. Function without arguments and without return type.
    2. Function with arguments and without return type.
    3. Function without arguments and with return type.
    4. Function with arguments and with return type.
*/

//Function without arguments and without return type.

//Function Declaration : Optional
//void Add();// void/null/empty means that function has no return value.

int main()
{
    Add(); // Function Calling
    Add();
    Add();
    Add();

    return 0;
}

//Function Definition
void Add() // Function Prototype
{
    int a, b;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    printf("Addition is: %d\n", (a + b));
}
