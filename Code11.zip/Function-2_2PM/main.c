#include <stdio.h>
#include <stdlib.h>

//2. Function with arguments and without return type.

void Add(int, int);

int main()
{
    Add(10, 20);// Function Arguments/Actual Arguments
    Add(40, 20);

    return 0;
}

void Add(int a, int b) // Function Parameters/ Formal Arguments
{
    printf("Addition is: %d\n", (a + b));
}
