#include <stdio.h>
#include <stdlib.h>

//4. Function with arguments and with return type.

int Add(int, int);

int main()
{
    printf("Addition is: %d", Add(10, 20));

    return 0;
}

int Add(int a, int b)
{
    return (a + b);
}
