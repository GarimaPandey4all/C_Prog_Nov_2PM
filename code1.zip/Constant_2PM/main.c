#include <stdio.h>
#include <stdlib.h>

int main()
{
    const int a = 10;//const - constant- fixed value

    a = 40; // re-initialization

    return 0;
}
