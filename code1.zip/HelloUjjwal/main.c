#include <stdio.h>
#include <stdlib.h> // stdlib : standard library
#include <conio.h>

int main()
{
    //clrscr(); //error
    printf("Hello, How are you?\n");
    getch();
    return 0;
}
