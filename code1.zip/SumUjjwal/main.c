#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;

    printf("Enter any value for a:");
    scanf("%d", &a);

    printf("Enter any value for b:");
    scanf("%d", &b);

    printf("Addition is: %d", (a + b));

    return 0;
}
