#include <stdio.h>
#include <stdlib.h>

int main()
{
    //variable: container that hold some value

    int a = 10;

    printf("a is: %d\n\n", a); // escape character : \n - new line

    a = 40;

    printf("a is: %d", a);

    return 0;
}
