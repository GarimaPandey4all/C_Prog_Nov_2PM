#include <stdio.h>
#include <stdlib.h>

int main()
{
    int array[2][2][2], i, j, k;

    printf("Enter values:\n");
    for(i = 0; i < 2; i++)
    {
        for(j = 0; j < 2; j++)
        {
            for(k = 0; k < 2; k++)
            scanf("%d", &array[i][j][k]);
        }
    }

    printf("Values in 3D-Array:\n");
    for(i = 0; i < 2; i++)
    {
        for(j = 0; j < 2; j++)
        {
            for(k = 0; k < 2; k++)
            printf("%d\t", array[i][j][k]); // \t : tab
        }
    }

    return 0;
}
