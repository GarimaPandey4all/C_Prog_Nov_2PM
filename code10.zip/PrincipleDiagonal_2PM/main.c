#include <stdio.h>
#include <stdlib.h>

int main()
{
    int matrix1[5][5], i, j, rows, columns;

    printf("Enter number of rows and columns:");
    scanf("%d %d", &rows, &columns);

    printf("Enter values in Matrix-1:\n");
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < columns; j++)
        {
            scanf("%d", &matrix1[i][j]);
        }
    }

    printf("Matrix-1:\n");
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < columns; j++)
        {
            printf("%d\t", matrix1[i][j]); // \t : tab
        }
        printf("\n");
    }

    printf("Principle Diagonal:\n");
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < columns; j++)
        {
            if(i == j)
                printf("%d  ", matrix1[i][j]);
        }
    }

    return 0;
}
