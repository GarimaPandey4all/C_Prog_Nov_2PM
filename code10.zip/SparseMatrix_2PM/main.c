#include <stdio.h>
#include <stdlib.h>

int main()
{
    int matrix1[5][5], i, j, rows, columns, count = 0;

    printf("Enter number of rows and columns:");
    scanf("%d %d", &rows, &columns);

    printf("Enter values in Matrix-1:\n");
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < columns; j++)
        {
            scanf("%d", &matrix1[i][j]);
        }
    }

    printf("Matrix-1:\n");
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < columns; j++)
        {
            printf("%d\t", matrix1[i][j]); // \t : tab
        }
        printf("\n");
    }

    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < columns; j++)
        {
            if(matrix1[i][j] == 0)
                count++;
        }
    }

    if(count > (rows * columns)/2)
        printf("Sparse Matrix");
    else
        printf("Not Sparse Matrix");

    return 0;
}
