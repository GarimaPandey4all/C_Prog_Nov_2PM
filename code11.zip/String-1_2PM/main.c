#include <stdio.h>
#include <stdlib.h>

/*
    String: It is a collection of characters.

    It is a character array in c.

    String Pre-Built Functions

    1. String Length
    2. String Copy
    3. String Concatenation/Joining
    4. String Compare
    5. String Uppercase/Lowercase

*/

int main()
{
    //char name[] = "Welcome";

    char name[10] = {'E', 'a', 't', '\0'}; // \0- terminator

    //printf("Enter your name:");
    //scanf("%s", name);

    //gets(name);

    //puts(name);
    printf("Your name is: %s\n", name);

    printf("Length of the string is: %d", strlen(name));

    return 0;
}
