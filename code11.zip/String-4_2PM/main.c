#include <stdio.h>
#include <stdlib.h>

/*
    String Compare:

    Str1 == str2 = 0
    a == a = 0
    a == b = 1
    b == a = -1
    a == c = 2
*/

int main()
{
    char str1[10];
    char str2[10];

    printf("Enter String:");
    gets(str1);

    printf("Enter String:");
    gets(str2);

    if(strcmp(str1, str2) == 0)
        printf("Same Strings: %d", strcmp(str1, str2));
    else
        printf("Not the Same Strings: %d", strcmp(str1, str2));

    return 0;
}
