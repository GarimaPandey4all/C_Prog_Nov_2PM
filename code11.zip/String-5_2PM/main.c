#include <stdio.h>
#include <stdlib.h>

int main()
{
    char str1[10];

    printf("Enter String:");
    gets(str1);

    printf("Uppercase is: %s\n", strupr(str1));
    printf("Lowercase is: %s\n", strlwr(str1));

    return 0;
}
