#include <stdio.h>
#include <stdlib.h>

int main()
{
    char name[] = "Welcome";
    int i;

    for(i = 0; name[i] != '\0'; i++)
    {

    }

    printf("String length is: %d", i);

    return 0;
}
