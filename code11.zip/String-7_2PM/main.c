#include <stdio.h>
#include <stdlib.h>

int main()
{
    char name[] = "Hello, how are you";
    int i, word = 1;

    for(i = 0; name[i] != '\0'; i++)
    {
        if(name[i] == ' ')
            word++;
    }

    printf("Total Words are: %d", word);

    return 0;
}
