#include <stdio.h>
#include <stdlib.h>

int main()
{
    char name[20];
    int i;

    printf("Enter any String:");
    gets(name);

    for(i = 0; name[i] != '\0'; i++)
    {
        //name[i] = name[i] + 32;//Lowercase
        name[i] = name[i] - 32;//Uppercase
    }

    printf("String is: %s", name);

    return 0;
}
