#include <stdio.h>
#include <stdlib.h>

int main()
{
    enum Week {Monday = 1, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday};

    enum Week today = Saturday;

    printf("Today is : %d", today);

    return 0;
}
