#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, fact = 1;

    printf("Enter any number to find the factorial:");
    scanf("%d", &n);

    for(i = 1; i <= n; i++)
    {
        fact *= i;
    }

    printf("Factorial is: %d", fact);

    return 0;
}
