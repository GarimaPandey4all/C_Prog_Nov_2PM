#include <stdio.h>
#include <stdlib.h>

// Date = 12 bytes

struct Date
{
    int day;
    int month;
    int year;
}date, date1;

//struct Date date;

int main()
{
    //struct Date date;

    date.day = 6;
    date.month = 12;
    date.year = 2020;

    date1.day = 7;
    date1.month = 12;
    date1.year = 2020;

    printf("Day = %d Month = %d Year = %d\n", date.day, date.month, date.year);

    printf("Day = %d Month = %d Year = %d", date1.day, date1.month, date1.year);

    return 0;
}
