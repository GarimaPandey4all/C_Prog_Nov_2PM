#include <stdio.h>
#include <stdlib.h>

// Date = 4 bytes

union Date
{
    int day;
    int month;
    int year;
}date;

//union Date date;

int main()
{
    //union Date date;

    date.day = 6;

    printf("Day = %d\n", date.day);

    date.month = 12;

    printf("Month = %d\n", date.month);

    date.year = 2020;

    printf("Year = %d\n", date.year);

    return 0;
}
