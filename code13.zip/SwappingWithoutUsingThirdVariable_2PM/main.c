#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

//    printf("Before swapping the value for a=%d and b= %d\n", a, b);
//
//    //First - Way: + and - Operators
//
//    //a = 4 b = 5
//
//    a = a + b; // 9
//    b = a - b; // 9 - 5 = 4
//    a = a - b; // 9 - 4 = 5
//
//    printf("After swapping the value for a=%d and b= %d", a, b);

//    printf("Before swapping the value for a=%d and b= %d\n", a, b);
//
//    //Second - Way: * and / Operators
//
//    //a = 4 b = 5
//
//    a = a * b; // 20
//    b = a / b; // 20 / 5 = 4
//    a = a / b; // 20 / 4 = 5
//
//    printf("After swapping the value for a=%d and b= %d", a, b);
//
    printf("Before swapping the value for a=%d and b= %d\n", a, b);

    //Third - Way: X-OR ^ Operator

    //a = 4 b = 5

    /*
        4 = 0000 0100
        5 = 0000 0101
            0000 0001 = 1
            0000 0100 = 4
            0000 0101

    */

    a = a ^ b; // 1
    b = a ^ b; // 4
    a = a ^ b; // 5

    printf("After swapping the value for a=%d and b= %d", a, b);

    return 0;
}
