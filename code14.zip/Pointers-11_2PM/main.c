#include <stdio.h>
#include <stdlib.h>

// Date = 12 bytes

struct Date
{
    int day;
    int month;
    int year;
}date, *pdate;

//struct Date date;

int main()
{
    //struct Date date;

    pdate = &date;

    (*pdate).day = 6;
    pdate->month = 12;
    pdate->year = 2020;

    printf("Day = %d Month = %d Year = %d\n", (*pdate).day, pdate->month, pdate->year);

    return 0;
}
