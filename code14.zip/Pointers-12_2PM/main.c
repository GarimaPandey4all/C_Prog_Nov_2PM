#include <stdio.h>
#include <stdlib.h>

// Date = 12 bytes

union Date
{
    int day;
    int month;
    int year;
}date, *pdate;

int main()
{
    pdate = &date;

    (*pdate).day = 6;

    printf("Day is: %d ", (*pdate).day);

    pdate->month = 12;

    printf("Month is: %d ", (*pdate).month);

    pdate->year = 2020;

    printf("Year is: %d", pdate->year);

    return 0;
}
