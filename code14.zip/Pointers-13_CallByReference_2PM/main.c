#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    printf("Before swapping the value of a = %d and b = %d\n", a, b);

    //Call by reference
    swap(&a, &b);

    printf("After swapping the value of a = %d and b = %d", a, b);

    return 0;
}

void swap(int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}
