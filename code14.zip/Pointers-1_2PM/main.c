#include <stdio.h>
#include <stdlib.h>

int main()
{
    int value = 100;

    int *pvalue = &value;

    printf("value is: %d\n", *pvalue); // * - Dereference Operator - Data/Value

    printf("value is: %d\n", pvalue); // address of value variable

    printf("value is: %d\n", &pvalue); // address of pointer variable

    return 0;
}
