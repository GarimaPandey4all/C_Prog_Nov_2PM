#include <stdio.h>
#include <stdlib.h>

int main()
{
    int value = 100;
    int a = 20;

    int *pvalue = NULL;

    pvalue = &value;

    printf("Value is: %d\n", *pvalue);

    *pvalue = 200;

    printf("Value is: %d\n", *pvalue);

    pvalue = &a;

    printf("Value is: %d\n", *pvalue);

    return 0;
}
