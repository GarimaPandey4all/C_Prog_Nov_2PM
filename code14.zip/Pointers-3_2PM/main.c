#include <stdio.h>
#include <stdlib.h>

int main()
{
    int count = 10, x;

    int *pcount = &count;

    x = *pcount; // 10

    printf("X is: %d\n", x);

    printf("Count is: %d", count);

    return 0;
}
