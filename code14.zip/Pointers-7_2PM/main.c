#include <stdio.h>
#include <stdlib.h>

// Pointer to a constant and constant pointer

int main()
{
    const int value = 10;
    int number = 20;

    //Pointer to a constant : value can't be changed
    //const int *pvalue = &value;

    //Constant Pointer : Address can't be changed
    //int *const pvalue = &value;

    const int *const pvalue = &value; // address and value both can't be changed

    //*pvalue = 30; // error

    //pvalue = &number; // error

    // value = 30; // error

    printf("Value is: %d", *pvalue);

    return 0;
}
