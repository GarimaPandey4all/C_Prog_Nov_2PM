#include <stdio.h>
#include <stdlib.h>

/*
    Calloc: stands for contiguous memory allocation.

    The malloc() function allocates memory and leaves the memory uninitialized.
    Whereas, the calloc() function allocates memory and initializes all bits to zero.
*/


int main()
{
    int size;
    char *text = NULL;

    printf("Enter limit of the text:");
    scanf("%d", &size);

    text = (char *)calloc(size, sizeof(char));

    if(text != NULL)
    {
        printf("Enter some text:\n");
        scanf(" ");
        gets(text);

        printf("Inputted text is: %s\n", text);
    }

    free(text);
    text = NULL;

    return 0;
}
