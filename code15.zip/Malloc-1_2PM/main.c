#include <stdio.h>
#include <stdlib.h>

/*
    Malloc: Stands for memory aalocation.

    The malloc() function reserves a block of memory of the specified number of bytes.
    And, it returns a pointer of void which can be casted into pointers of any form/type.

*/

int main()
{
    int size;
    char *text = NULL;

    printf("Enter limit of the text:");
    scanf("%d", &size);

    text = (char *)malloc(size * sizeof(char));

    if(text != NULL)
    {
        printf("Enter some text:\n");
        scanf(" ");
        gets(text);

        printf("Inputted text is: %s\n", text);
    }

    free(text);
    text = NULL;

    return 0;
}
