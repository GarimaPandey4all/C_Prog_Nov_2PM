#include <stdio.h>
#include <stdlib.h>

/*
    Realloc(): If the dynamically allocated memory is insufficient or more than required,
    you can change the size of previously allocated memory using the realloc() function.
*/

int main()
{
    char *str;

    str = (char *) malloc(15);

    strcpy(str, "Jason");
    printf("String: %s, Address: %u\n", str, str);

    str = (char *)realloc(str, 25);
    strcat(str, ".com");
    printf("String: %s, Address: %u", str, str);

    free(str);

    return 0;
}
