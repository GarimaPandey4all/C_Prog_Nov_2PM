#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *fp = NULL;

    fp = fopen("file.txt", "a"); // a- append mode

    //Create and write in an existing file at the end.

    if(fp != NULL)
    {
        fprintf(fp, "%s %d\n", "Hello", 555);
    }

    fclose(fp);
    fp = NULL;

    return 0;
}
