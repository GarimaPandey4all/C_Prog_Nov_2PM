#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *fp = NULL;
    FILE *fp1 = NULL;

    char ch;

    fp = fopen("file.txt", "r");

    if(fp == NULL)
    {
        printf("Error in opening file");
        exit(0);
    }

    //Create a temp file
    fp1 = fopen("temp.txt", "w");

    if(fp1 == NULL)
    {
        printf("Error in opening file");
        exit(0);
    }

    while((ch = fgetc(fp)) != EOF)
    {
        if(islower(ch))
        {
            ch = ch - 32; // ch = a - 32; // 97 - 32 = 65
        }

        fputc(ch, fp1);
    }

    fclose(fp);
    fclose(fp1);

    remove("file.txt");

    fp = NULL;
    fp1 = NULL;

    return 0;
}
