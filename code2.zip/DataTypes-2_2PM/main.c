#include <stdio.h>
#include <stdlib.h>

int main()
{
    signed short int x = 32769;

    //printf("x is: %d\n", x);

    printf("x is: %u\n", x);

    return 0;
}
