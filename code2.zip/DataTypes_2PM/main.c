#include <stdio.h>
#include <stdlib.h>

/*
    1 byte = 8 bits

    int - 2 or 4 bytes
    char - 1 byte
    float - 4 bytes
    double - 8 bytes
*/

int main()
{
    int a = 10;
    char b = 'A';
    float c = 34.67f;
    double d = 67.89;

    printf("A is: %d\n", a);
    printf("B is: %c\n", b);
    printf("C is: %.2f\n", c);
    printf("D is: %lf\n\n", d);

    //sizeof operator
    printf("size of int: %d\n", sizeof(a));
    printf("size of char: %d\n", sizeof(char));
    printf("size of float: %d\n", sizeof(c));
    printf("size of double: %d\n", sizeof(double));

    return 0;
}
