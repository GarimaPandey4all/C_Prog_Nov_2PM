#include <stdio.h>
#include <stdlib.h>

int main()
{
    int ch;

    printf("Enter any number:");
    scanf("%d", &ch);

    printf("Entered number's character is: %c", ch);

    return 0;
}
