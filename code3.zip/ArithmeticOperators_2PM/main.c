#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;

    printf("Enter any value for a:");
    scanf("%d", &a);

    printf("Enter any value for b:");
    scanf("%d", &b);

    //a = 4, b = 5

    printf("Addition is: %d\n", (a + b));
    printf("Subtraction is: %d\n", (a - b));
    printf("Multiplication is: %d\n", (a * b));
    printf("Division is: %d\n", (a / b));
    printf("Modulus is: %d\n", (a % b)); // 4

    //Pre and Post Increment
    printf("Pre-Increment:%d\n",++a); // 5
    printf("Post-Increment:%d\n",a++); // 5
    printf("A is: %d\n", a); // 6

    //Pre and Post Decrement
    printf("Pre-Decrement:%d\n",--b); // 4
    printf("Post-Decrement:%d\n",b--); // 4
    printf("B is: %d\n", b); // 3

    return 0;
}
