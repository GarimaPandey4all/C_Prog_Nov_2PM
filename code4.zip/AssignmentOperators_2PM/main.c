#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 10; // = : Assignment Operator

    a += 60; //a = a + 60;

    printf("A is: %d\n", a);

    printf("Address of a: %u", &a);

    return 0;
}
