#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    printf("Bitwise AND Operator: %d\n", (a & b));
    printf("Bitwise OR Operator: %d\n", (a | b));
    printf("Bitwise Not Operator: %d\n", ~(a));
    printf("Bitwise X-OR Operator: %d\n", (a ^ b));
    printf("Bitwise Left Shift Operator: %d\n", (a<<1));
    printf("Bitwise Right Shift Operator: %d\n", (a>>1));

    return 0;
}
