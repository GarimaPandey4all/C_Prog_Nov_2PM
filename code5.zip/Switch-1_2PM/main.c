#include <stdio.h>
#include <stdlib.h>

//Switch: Menu Driven Program

int main()
{
    int choice, a, b;

    printf("\n\nPress 1. Addition");
    printf("\nPress 2. Subtraction");
    printf("\nPress 3. Multiplication");
    printf("\nPress 4. Division");

    printf("\n\nEnter your choice:");
    scanf("%d", &choice);

    switch(choice)
    {
    case 1:
        printf("Enter any value for a and b:");
        scanf("%d %d", &a, &b);

        printf("Addition is: %d", (a + b));
        break;

    case 2:
        printf("Enter any value for a and b:");
        scanf("%d %d", &a, &b);

        printf("Subtraction is: %d", (a - b));
        break;

    case 3:
        printf("Enter any value for a and b:");
        scanf("%d %d", &a, &b);

        printf("Multiplication is: %d", (a * b));
        break;

    case 4:
        printf("Enter any value for a and b:");
        scanf("%d %d", &a, &b);

        printf("Division is: %d", (a / b));
        break;

    default:
        printf("Invalid Choice");

    }

    return 0;
}
