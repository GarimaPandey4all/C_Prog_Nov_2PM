#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i = 1;

//    for(i = 1; i <= 10; i++)
//    {
//        printf("Hello world!\n");
//    }

//     while(i <= 10)
//     {
//        printf("Hello World\n");
//        i++;
//     }

    do
    {
        printf("Hello World\n");
        i++;
    }while(i <= 10);

    return 0;
}
