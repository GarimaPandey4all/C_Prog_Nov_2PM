#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, j;

    //Nested Loops
    for(i = 1; i <= 5; i++) // Rows
    {
        for(j = 1; j <= 5; j++) // Columns
        {
            //printf("*");
            //printf("%d", i);
            printf("%d", j);
        }
        printf("\n");
    }

    return 0;
}
