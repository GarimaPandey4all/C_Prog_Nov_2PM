#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, j;

    //Nested Loops
    for(i = 5; i >= 1; i--) // Rows
    {
        for(j = 5; j >= 1; j--) // Columns
        {
            printf("%d", i);
            //printf("%d", j);
        }
        printf("\n");
    }

    return 0;
}
