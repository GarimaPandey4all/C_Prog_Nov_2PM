#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, j;

    for(i = 101; i >= 97; i--)
    {
        for(j = i; j >= 97; j--)
        {
            printf("%c", i);
            //printf("%c", j);
        }

        printf("\n");
    }

    return 0;
}
