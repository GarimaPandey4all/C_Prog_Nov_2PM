#include <stdio.h>
#include <stdlib.h>

//Array: It is a collection of similar types of items/elements.
//It is also called contiguous memory allocation.

int main()
{
    int arr[5]; // declaration of an array // [] - closed bracket / subscript operator

    //Traditional way to initialization array
    //int arr[5] = {10, 20, 30, 40, 50}; // declare and initialize

    //Compile time initialization
    //int arr[] = {10, 20, 30, 40, 50};

//    arr[0] = 10;
//    arr[1] = 20;
//    arr[2] = 30;
//    arr[3] = 40;
//    arr[4] = 50;

    printf("Enter values in an Array:\n");
    for(int i = 0; i < 5; i++)
    {
        scanf("%d", &arr[i]);
    }
//
//    printf("First value: %d\n", arr[0]);
//    printf("Second value: %d\n", arr[1]);
//    printf("Third value: %d\n", arr[2]);
//    printf("Fourth value: %d\n", arr[3]);
//    printf("Fifth value: %d\n", arr[4]);

    printf("Values of the Array are:\n");
    for(int i = 0; i < 5; i++)
    {
        printf("%d  ", arr[i]);
    }

    return 0;
}
