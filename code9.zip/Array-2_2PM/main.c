#include <stdio.h>
#include <stdlib.h>
#define MONTHS 12 // macros

//Macros: create your own pre - processor directive or header file

int main()
{
    //const int MONTHS = 12; // error

    int days[MONTHS] = {31, 29, 30, 31, 30, 31, 30, 31, 30, 31, 30, 31};

    for(int i = 0; i < MONTHS; i++)
    {
        printf("%d month has %d days\n", i + 1, days[i]);
    }

    return 0;
}
